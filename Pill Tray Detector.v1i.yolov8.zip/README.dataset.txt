# Pill Tray Detector > 2025-09-04 2:21am
https://universe.roboflow.com/nilays-workspace/pill-tray-detector-tfin3

Provided by a Roboflow user
License: CC BY 4.0

